# -*- coding: utf-8 -*-
"""只读收尾 (2): 核查 use_history 开关是否只移除【过去】信息。
纯张量计算, 不跑任何导航。
构造「零有效过去帧」的 prefix（只有最后一帧=当前帧被 measured），
比较 use_history True/False 的 score_candidates。若不同 -> 开关也移除了当前帧的记忆写入。
"""
import sys, configparser, numpy as np, torch
sys.path.insert(0,'/home/abc/workspace/shixu/vendor'); sys.path.insert(1,'/home/abc/workspace/shixu')
import crowd_sim as _cs; assert _cs.__file__.startswith('/home/abc/workspace/shixu/vendor/')
from shixu.model import build_model, load_weights
P='/home/abc/workspace/shixu/outputs/occlusion_v8/419/motion_kda/model.pt'
ck=torch.load(P,map_location='cpu',weights_only=False)
cfg=configparser.ConfigParser(); cfg.read_dict(ck['config'])
m=build_model(cfg); load_weights(m,P,'cpu'); m.eval()
print("full_observed_window =", getattr(m,'full_observed_window',False),
      " seq_len =", cfg.getint('buffer','seq_len'))
T=cfg.getint('buffer','seq_len')-1          # score 里 prefix[1:] 之后的长度
P_=3; D=13                                   # 3 人; token 维度
torch.manual_seed(0)
def make(n_measured_past):
    """prefix: [1, T, 1+P_, D]; 第 0 列是 robot, 其余是人。
       只让最后 n_measured_past+1 帧里的最后一帧(当前帧)以及最早 n_measured_past 帧 measured。"""
    pre=torch.zeros(1,T,1+P_,D)
    pre[:,:,:, :]=torch.randn(1,T,1+P_,D)*0.1
    # active(列12) 与 measured(列10) 全部先关掉
    pre[:,:,1:,12]=0.0; pre[:,:,1:,10]=0.0
    idx=list(range(T-1-n_measured_past, T))   # 末尾 n+1 帧
    for t in idx:
        pre[:,t,1:,12]=1.0; pre[:,t,1:,10]=1.0
    return pre
q=torch.randn(1,80,1+P_,D)*0.1
q[:,:,1:,12]=1.0
res={}
for npast in (0,1,3,10):
    pre=make(npast)
    out={}
    for flag in (True,False):
        orig=m.use_history
        try:
            m.use_history=flag
            with torch.inference_mode():
                out[flag]=m.score_candidates(pre,q).squeeze(0).numpy().copy()
        finally:
            m.use_history=orig
    d=np.abs(out[True]-out[False])
    res[npast]=(float(d.max()), int(np.argmax(out[True])), int(np.argmax(out[False])))
    print(f"  有效过去帧 {npast:2d}:  |Δscore| 最大 {d.max():.6e}   "
          f"argmax 有历史 {np.argmax(out[True]):2d} / 零历史 {np.argmax(out[False]):2d}  "
          f"{'一致' if np.argmax(out[True])==np.argmax(out[False]) else '不同'}")
z=res[0][0]
print(f"\n[判读] 零有效过去帧时 |Δscore| 最大 = {z:.6e}")
print("        > 0 -> 开关【不只】移除过去信息, 当前帧的记忆写入也被移除")
print("        = 0 -> 开关只移除过去信息")
