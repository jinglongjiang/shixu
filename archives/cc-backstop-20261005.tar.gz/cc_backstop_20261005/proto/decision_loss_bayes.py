# -*- coding: utf-8 -*-
"""兜底仪器 A（贝叶斯线）：把 V23 的真实损失从"四臂选中的 1–3 个指令"铺满到"全部 feasible control"。

动机（来自 R1 自己的记录）：V23 的 8 个 context × 17 个 control = 136 个可能的 realize，
实际只做了约 14 个；四臂一旦收敛到同一指令就只有 1 次 realize，于是 6 个 context 里
4 个"四臂同动作"。那不是状态里没有差异，是没有去量。

本脚本【完全复用】R1 已审计过的 realize()/restore_context()/context_key()，不另写一套语义。
唯一改变：realize 的指令集合从"臂的选择"换成"全部 feasible"。
不写入 R1 的任何目录；产物只落 /home/abc/temp/cc_backstop_20261005/results。

自检：对四臂实际选中过的指令，本脚本必须复现 R1 存档的 task_cost（原子对照）。
"""
import os, sys, json, time, argparse, copy
from pathlib import Path
import numpy as np

R1 = '/home/abc/workspace/bayesian_nonconsensus_reaudit_20261003'
sys.path.insert(0, R1)
os.chdir(R1)                      # 他们的模块用 Path(__file__).parent, 但 restore 可能依赖 cwd
import constraint_release_bayes as cr
from run_constrained_branch_outcomes import (
    restore_context, context_key, realize, scores, OUT)
from run_reset_release_queries import key
from policy_tail_model import PolicyTailModel

ap = argparse.ArgumentParser()
ap.add_argument('--limit-contexts', type=int, default=0, help='0=全部')
ap.add_argument('--limit-controls', type=int, default=0, help='0=全部 feasible')
ap.add_argument('--workers', type=int, default=4)
ap.add_argument('--selfcheck-only', action='store_true')
ap.add_argument('--out', default='/home/abc/temp/cc_backstop_20261005/results')
a = ap.parse_args()
Path(a.out).mkdir(parents=True, exist_ok=True)

records = json.loads((OUT/'constrained_goal_branches_results.json').read_text())
stored  = json.loads((OUT/'constrained_branch_outcomes_results.json').read_text())
source  = {r: json.loads((OUT/('stop_resume_bayes_outcome_r%d_results.json' % r)).read_text())
           for r in (0, 1)}

grouped = {}
for record in records:
    actual = next(r for r in source[record['replica']] if key(r['root']) == key(record['root']))
    grouped.setdefault(context_key(record, actual), []).append((record, actual))
ctxs = list(grouped.values())
print(f"[ctx] 唯一 context {len(ctxs)} 个（与 R1 main() 同一分组口径）", flush=True)

def stored_for(record):
    """找 R1 存档里同 root/replica/prefix_arm 的那条"""
    for s in stored:
        if key(s['root']) == key(record['root']) and s['replica'] == record['replica'] \
           and s['prefix_arm'] == record['arm']:
            return s
    return None

def run_context(pairs, limit_controls):
    record, actual = pairs[0]
    env, model, belief = restore_context(record, actual)
    sh = record['action_shadow']
    controls = np.asarray(sh['controls']); feasible = np.asarray(sh['feasible'])
    idxs = [i for i in range(len(controls)) if feasible[i]]
    if limit_controls: idxs = idxs[:limit_controls]
    post = record['end_transition'] - record['root']['step']
    out = {}
    for i in idxs:
        t0 = time.perf_counter()
        r = realize(env, belief, tuple(controls[i]), record['root']['case'], post)
        out[i] = {k: r[k] for k in ('success','timeout','collision_steps','wall_collision_steps',
                                    'minimum_clearance','task_cost','path_length','elapsed','progress')}
        out[i]['seconds'] = time.perf_counter()-t0
    return record, actual, controls, feasible, out

# ---------- 自检：复现 R1 存档的 task_cost ----------
print("[自检] 对 R1 已 realize 过的指令重跑, 必须逐位复现 task_cost", flush=True)
pairs = ctxs[0]; record, actual = pairs[0]
s = stored_for(record)
assert s is not None, "找不到对应的 R1 存档记录"
env, model, belief = restore_context(record, actual)
ctrls = np.asarray(record['action_shadow']['controls'])
ok = True
for arm, ai in s['actions'].items():
    want = s['outcomes'][arm]['task_cost']
    t0 = time.perf_counter()
    got = realize(env, belief, tuple(ctrls[ai]), record['root']['case'],
                  record['end_transition']-record['root']['step'])['task_cost']
    same = abs(got-want) < 1e-12
    ok &= same
    print(f"  {arm:30s} control#{ai:2d}  R1存档 {want:.10f}  本脚本 {got:.10f}  "
          f"{'一致' if same else '不一致'}   ({time.perf_counter()-t0:.1f}s/次)", flush=True)
print(f"[自检] {'通过' if ok else '失败'}", flush=True)
json.dump({'selfcheck_pass': bool(ok)}, open(f'{a.out}/selfcheck_bayes.json','w'))
if not ok or a.selfcheck_only:
    sys.exit(0 if ok else 1)

# ---------- 铺满 ----------
from concurrent.futures import ProcessPoolExecutor, as_completed
todo = ctxs[:a.limit_contexts] if a.limit_contexts else ctxs
res = []
with ProcessPoolExecutor(max_workers=a.workers) as pool:
    futs = {pool.submit(run_context, p, a.limit_controls): p for p in todo}
    for f in as_completed(futs):
        record, actual, controls, feasible, out = f.result()
        s = stored_for(record)
        costs = {i: v['task_cost'] for i, v in out.items()}
        best = min(costs, key=costs.get); worst = max(costs, key=costs.get)
        row = {
          'root': record['root'], 'replica': record['replica'], 'prefix_arm': record['arm'],
          'end_transition': record['end_transition'],
          'n_feasible': int(feasible.sum()), 'n_realized': len(out),
          'controls': controls.tolist(), 'feasible': feasible.tolist(),
          'per_control': {str(k): v for k, v in out.items()},
          'true_best_control': int(best), 'true_best_cost': costs[best],
          'true_worst_cost': costs[worst],
          'headroom': costs[worst]-costs[best],
          'arm_actions': s['actions'] if s else None,
          'arm_decision_loss': ({k: costs.get(v, None) if costs.get(v) is None else costs[v]-costs[best]
                                 for k, v in s['actions'].items()} if s else None),
        }
        res.append(row)
        json.dump(res, open(f'{a.out}/decision_loss_bayes.json','w'), indent=1)
        print(f"[done] case{record['root']['case']} step{record['root']['step']} r{record['replica']} "
              f"{record['arm']}  realize {len(out)}/{int(feasible.sum())}  "
              f"真实最优 #{best}={costs[best]:.4f}  最差={costs[worst]:.4f}  "
              f"headroom={row['headroom']:.4f}  臂损失={ {k:(None if v is None else round(v,4)) for k,v in (row['arm_decision_loss'] or {}).items()} }",
              flush=True)
print(f"[全部完成] {len(res)} 个 context", flush=True)
