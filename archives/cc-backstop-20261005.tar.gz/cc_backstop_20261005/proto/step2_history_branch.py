# -*- coding: utf-8 -*-
"""第二步：已训练 KDA 中「因历史而改变的动作」在真实后果上更好、更差，还是没有实用差别。

严格按用户给定的三条补充：
 (1) 首次分歧只在【同一条冻结参考轨迹】上寻找。状态恢复用确定性重放 + 逐位断言
     （env/tracks 含 rvo2 C 扩展, deepcopy 不可行, 已 smoke 验证）。
     重放恢复的是真实状态、记忆窗口(policy.history)、跟踪器(OccludedTracks)、
     平滑器(policy.last_action) 与随机状态 —— 全部由重放精确重建, 并断言指纹一致。
 (2) 清空干预【只影响根动作选择】; 根步之后两条分支都用 use_history=True 正常续跑,
     各自从自己的真实观测合法更新。评分对 history 只读 (window(list(history)+[...]) 是拷贝),
     所以两次候选查询都不污染续跑所用的记忆。
 (3) 同时报「始终没有动作分歧」的 episode 数。每个 episode 只取【一个】锚点(首次分歧),
     因此不存在多锚点当独立样本的问题; 统计按 episode 分组。

预注册的三分类（阈值先写定, 并报阈值敏感性）:
  同一 terminal 且 |Δ真实折扣回报| <= 0.02  -> 「动作不同但后果相近」
  否则按 Δ 的符号  -> 「历史带来有益动作」/「历史带来有害动作」
Δ = (有历史分支的回报) − (零历史分支的回报)，从分歧步起算。

边界：清空记忆是分布外干预, 结论只说明该干预的影响, 不证明历史有害。
不剔除任何种子, 不重训, 不复活 KDA 开发。
"""
import sys, os, json, time, argparse, configparser
import numpy as np, torch
# shixu 用的是自己 vendor 下的 crowd_sim; 默认 sys.path 上另有一份 soc-nav-training 的副本,
# 若解析错会静默得到不同的 env.step 契约。vendor 必须先于一切。
sys.path.insert(0, '/home/abc/workspace/shixu/vendor')
sys.path.insert(1, '/home/abc/workspace/shixu')
import crowd_sim as _cs
assert _cs.__file__.startswith('/home/abc/workspace/shixu/vendor/'), \
    f"crowd_sim 解析错误: {_cs.__file__}"
from crowd_sim.envs.utils.action import ActionXY
from shixu.model import build_model, load_weights
from shixu.policy import ValuePolicy
from shixu.observations import OccludedTracks
from shixu.runner import environment

ap = argparse.ArgumentParser()
ap.add_argument('--seeds', default='419,443,467,491')
ap.add_argument('--people', default='10,20')          # 主指标 cohort
ap.add_argument('--geometries', default='circle,square')
ap.add_argument('--cases', default='30000,30016')     # [start, end)
ap.add_argument('--arm', default='motion_kda')
ap.add_argument('--tol', type=float, default=0.02)
ap.add_argument('--out', default='/home/abc/temp/cc_backstop_20261005/results')
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
C0, C1 = [int(x) for x in a.cases.split(',')]

def load(seed):
    p = f'/home/abc/workspace/shixu/outputs/occlusion_v8/{seed}/{a.arm}/model.pt'
    if not os.path.exists(p): return None, None, None
    ck = torch.load(p, map_location='cpu', weights_only=False)
    cfg = configparser.ConfigParser(); cfg.read_dict(ck['config'])
    pol = ValuePolicy(build_model(cfg), cfg, 'cpu')
    load_weights(pol.model, p, 'cpu'); pol.model.eval()
    return pol, cfg, p

def fingerprint(env):
    return (np.array(env.robot.get_full_state().to_array(), dtype=np.float64),
            np.array([h.get_observable_state().to_array() for h in env.humans], dtype=np.float64),
            float(env.global_time))

def new_episode(env, pol, case):
    pol.reset(); pol.set_phase('test'); env.phase = 'test'
    env.reset(options={'test_case': int(case)})
    return OccludedTracks(pol.config.getfloat('observation', 'retention_seconds'))

def scores_both(pol, state):
    """同一状态上算 use_history=True / False 两套打分; 只读, 不改任何持久状态。"""
    orig = pol.model.use_history
    try:
        pol.model.use_history = True;  sf = np.asarray(pol.score(state))
        pol.model.use_history = False; sz = np.asarray(pol.score(state))
    finally:
        pol.model.use_history = orig
    return int(np.argmax(sf)), int(np.argmax(sz))

def apply_index(pol, state, idx):
    """复刻 predict 的尾部（含 RNG 抽样与平滑器），但用指定 index。"""
    _ = np.random.random()                                   # 与 predict 的抽样对齐
    sel = pol.action_space[idx]
    pol.history.append(pol.encode(state))
    al = pol.config.getfloat('eval_protocol', 'action_smoothing') if pol.phase != 'train' else 0
    if pol.last_action is not None and al > 0:
        sel = ActionXY(al*pol.last_action.vx + (1-al)*sel.vx, al*pol.last_action.vy + (1-al)*sel.vy)
    pol.last_action = sel
    return sel

def reference(env, pol, case):
    """冻结参考轨迹：use_history=True 正常运行；每步同时记录零历史的 argmax。"""
    tracks = new_episode(env, pol, case)
    fps, acts, idx_f, idx_z, rews = [], [], [], [], []
    done = trunc = False; info = {}
    while not (done or trunc):
        fps.append(fingerprint(env))
        st = tracks.observe(env)
        f, z = scores_both(pol, st)
        idx_f.append(f); idx_z.append(z)
        act = apply_index(pol, st, f)
        acts.append(act)
        _, r, done, trunc, info = env.step(act)
        rews.append(float(r))
    return dict(fingerprints=fps, actions=acts, idx_full=idx_f, idx_zero=idx_z,
                rewards=rews, terminal=info.get('event'), steps=len(acts))

def replay_to(env, pol, case, ref, k):
    """重放到第 k 步（执行参考记录的动作），并断言指纹逐位一致。"""
    tracks = new_episode(env, pol, case)
    for i in range(k):
        got = fingerprint(env); want = ref['fingerprints'][i]
        np.testing.assert_allclose(got[0], want[0], atol=0, rtol=0)
        np.testing.assert_allclose(got[1], want[1], atol=0, rtol=0)
        assert got[2] == want[2]
        st = tracks.observe(env)
        _ = np.random.random()                       # 对齐 predict 的抽样
        pol.history.append(pol.encode(st))
        al = pol.config.getfloat('eval_protocol', 'action_smoothing') if pol.phase != 'train' else 0
        sel = ref['actions'][i]
        pol.last_action = sel
        env.step(sel)
    got = fingerprint(env); want = ref['fingerprints'][k]
    np.testing.assert_allclose(got[0], want[0], atol=0, rtol=0)
    np.testing.assert_allclose(got[1], want[1], atol=0, rtol=0)
    return tracks

def branch(env, pol, case, ref, k, root_idx, rng_state):
    """从第 k 步分支：根动作用 root_idx，之后一律 use_history=True 正常续跑。"""
    np.random.set_state(rng_state)
    tracks = replay_to(env, pol, case, ref, k)
    st = tracks.observe(env)
    act = apply_index(pol, st, root_idx)
    _, r, done, trunc, info = env.step(act)
    rews = [float(r)]
    while not (done or trunc):
        st = tracks.observe(env)
        act = pol.predict(st, 0.0)               # 正常策略, 带历史
        _, r, done, trunc, info = env.step(act)
        rews.append(float(r))
    g = 0.0
    for r in reversed(rews): g = r + pol.gamma*g
    return dict(ret=g, terminal=info.get('event'), steps=len(rews))

rows = []; t_start = time.time()
for seed in [int(s) for s in a.seeds.split(',')]:
    pol, cfg, path = load(seed)
    if pol is None: print(f"[缺失] seed {seed} 无 {a.arm}/model.pt", flush=True); continue
    for people in [int(x) for x in a.people.split(',')]:
        for geom in a.geometries.split(','):
            env = environment(cfg, pol, geom, people)
            for case in range(C0, C1):
                np.random.seed(1000000 + 97*seed + 13*people + (0 if geom=='circle' else 1) + case)
                rng0 = np.random.get_state()
                ref = reference(env, pol, case)
                # 自检：同一 RNG 起点重跑参考轨迹必须逐位一致
                np.random.set_state(rng0)
                ref2 = reference(env, pol, case)
                det = (ref['idx_full'] == ref2['idx_full'] and ref['idx_zero'] == ref2['idx_zero']
                       and np.allclose(ref['rewards'], ref2['rewards'], atol=0, rtol=0))
                divs = [i for i,(f,z) in enumerate(zip(ref['idx_full'], ref['idx_zero'])) if f != z]
                row = dict(seed=seed, people=people, geometry=geom, case=case,
                           deterministic=bool(det), steps=ref['steps'],
                           terminal_ref=ref['terminal'], n_divergent_steps=len(divs),
                           first_div=(divs[0] if divs else None))
                if divs:
                    k = divs[0]
                    bf = branch(env, pol, case, ref, k, ref['idx_full'][k], rng0)
                    bz = branch(env, pol, case, ref, k, ref['idx_zero'][k], rng0)
                    row.update(full_ret=bf['ret'], zero_ret=bz['ret'],
                               full_terminal=bf['terminal'], zero_terminal=bz['terminal'],
                               full_steps=bf['steps'], zero_steps=bz['steps'],
                               delta=bf['ret']-bz['ret'])
                    same_term = bf['terminal'] == bz['terminal']
                    row['klass'] = ('no_practical_difference' if (same_term and abs(row['delta'])<=a.tol)
                                    else ('history_beneficial' if row['delta']>0 else 'history_harmful'))
                rows.append(row)
                json.dump(rows, open(f'{a.out}/step2_history_branch.json','w'), indent=1)
                print(f"[{seed} {people}p {geom} c{case}] det={det} steps={ref['steps']} "
                      f"ref={ref['terminal']} 分歧步={len(divs)}"
                      + (f" 首次@{row['first_div']} Δ={row['delta']:+.4f} "
                         f"({row['full_terminal']} vs {row['zero_terminal']}) -> {row['klass']}" if divs else " (无分歧)"),
                      flush=True)
print(f"[完成] {len(rows)} episodes, {time.time()-t_start:.0f}s", flush=True)
