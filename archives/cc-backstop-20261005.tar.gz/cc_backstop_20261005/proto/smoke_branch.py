# -*- coding: utf-8 -*-
"""§8 smoke: 分支所需的状态恢复是否可行。
优先 deepcopy; 若 rvo2 等 C 扩展不可复制, 则退回"从 episode 起点确定性重放 + 逐位断言"。
"""
import sys, copy, configparser, numpy as np, torch
sys.path.insert(0, '/home/abc/workspace/shixu')
from shixu.model import build_model, load_weights
from shixu.policy import ValuePolicy
from shixu.observations import OccludedTracks
from shixu.runner import environment
P='/home/abc/workspace/shixu/outputs/occlusion_v8/419/motion_kda/model.pt'
ck=torch.load(P, map_location='cpu', weights_only=False)
cfg=configparser.ConfigParser(); cfg.read_dict(ck['config'])
pol=ValuePolicy(build_model(cfg), cfg, 'cpu'); load_weights(pol.model, P, 'cpu'); pol.model.eval()
print("read_clock =", cfg.get('model','read_clock',fallback='candidate'),
      " representation =", cfg.get('model','representation',fallback='legacy'),
      " action_smoothing =", cfg.get('eval_protocol','action_smoothing',fallback='0'),
      " seq_len =", cfg.getint('buffer','seq_len'))
np.random.seed(419)
env=environment(cfg, pol, 'circle', 10)
pol.reset(); pol.set_phase('test'); env.phase='test'; env.reset(options={'test_case':30000})
tracks=OccludedTracks(pol.config.getfloat('observation','retention_seconds'))
# 走 3 步
for _ in range(3):
    st=tracks.observe(env); a=pol.predict(st, 0.0); env.step(a)
print("\n--- deepcopy 可行性 ---")
for name,obj in (('env',env), ('tracks',tracks), ('policy.history',pol.history)):
    try:
        c=copy.deepcopy(obj); print(f"  {name:16s} deepcopy OK")
    except Exception as e:
        print(f"  {name:16s} deepcopy 失败: {type(e).__name__}: {str(e)[:90]}")
print("\n--- 分支等价性: deepcopy 后两条各走一步, 同一动作应得到同一状态 ---")
try:
    snap=(copy.deepcopy(env), copy.deepcopy(tracks), copy.deepcopy(pol.history), pol.last_action, np.random.get_state())
    def run_one(snap, idx):
        e2,t2,h2,la,rs = snap
        e2=copy.deepcopy(e2); t2=copy.deepcopy(t2)
        pol.history=copy.deepcopy(h2); pol.last_action=la; np.random.set_state(rs)
        e2.robot.set_policy(pol); e2.robot.env=e2
        st=t2.observe(e2); sc=pol.score(st)
        _=np.random.random()                       # 与 predict 的抽样对齐
        from crowd_sim.envs.utils.action import ActionXY
        sel=pol.action_space[idx]
        pol.history.append(pol.encode(st))
        al=pol.config.getfloat('eval_protocol','action_smoothing') if pol.phase!='train' else 0
        if pol.last_action is not None and al>0:
            sel=ActionXY(al*pol.last_action.vx+(1-al)*sel.vx, al*pol.last_action.vy+(1-al)*sel.vy)
        pol.last_action=sel
        _,r,d,tr,info=e2.step(sel)
        return float(e2.robot.px), float(e2.robot.py), float(r), int(np.argmax(sc))
    A=run_one(snap, 5); B=run_one(snap, 5)
    print(f"  两次同动作分支: A={A}  B={B}  {'一致' if A==B else '不一致'}")
    C=run_one(snap, 9)
    print(f"  换动作分支:     C={C}  {'与 A 不同(预期)' if C[:2]!=A[:2] else '与 A 相同(异常)'}")
except Exception as e:
    import traceback; traceback.print_exc()
