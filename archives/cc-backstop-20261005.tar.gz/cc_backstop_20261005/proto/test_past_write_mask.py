# -*- coding: utf-8 -*-
"""只移除过去信息 (mask_past_writes) 的单测。不跑导航。
TREE 环境变量决定用哪棵源码树（原版 / 打补丁版），便于关闭新功能后的回归对照。
"""
import sys, os, json, hashlib, configparser, numpy as np, torch
TREE = os.environ.get('TREE', '/home/abc/temp/cc_backstop_20261005/shixu_patched')
sys.path.insert(0, '/home/abc/workspace/shixu/vendor'); sys.path.insert(1, TREE)
import crowd_sim as _cs; assert _cs.__file__.startswith('/home/abc/workspace/shixu/vendor/')
import shixu as _sx; assert _sx.__file__.startswith(TREE), f"shixu 解析错误: {_sx.__file__}"
from shixu.model import build_model, load_weights

CKPTS = {'motion_kda': '/home/abc/workspace/shixu/outputs/occlusion_v8/419/motion_kda/model.pt',
         'gru_context': '/home/abc/workspace/shixu/outputs/occlusion_v8/419/gru_context/model.pt',
         'motion_gru': '/home/abc/workspace/shixu/outputs/occlusion_v8/419/motion_gru/model.pt'}
ACT, MEA = 12, 10          # token 列：active / measured
P_, D = 3, 13

def build(name):
    ck = torch.load(CKPTS[name], map_location='cpu', weights_only=False)
    cfg = configparser.ConfigParser(); cfg.read_dict(ck['config'])
    m = build_model(cfg); load_weights(m, CKPTS[name], 'cpu'); m.eval()
    T = cfg.getint('buffer', 'seq_len') - (0 if getattr(m, 'full_observed_window', False) else 1)
    return m, cfg, T, type(m).__name__

def make(T, past_measured_frames, hidden_person_with_past=False, seed=0):
    """prefix (1,T,1+P_,D)。最后一帧=当前帧。past_measured_frames 指当前帧【之前】有多少帧被 measured。"""
    g = torch.Generator().manual_seed(seed)
    pre = torch.randn(1, T, 1 + P_, D, generator=g) * 0.1
    pre[:, :, 1:, ACT] = 0.0; pre[:, :, 1:, MEA] = 0.0
    pre[:, -1, 1:, ACT] = 1.0; pre[:, -1, 1:, MEA] = 1.0          # 当前帧全部 measured
    for t in range(T - 1 - past_measured_frames, T - 1):
        pre[:, t, 1:, ACT] = 1.0; pre[:, t, 1:, MEA] = 1.0
    if hidden_person_with_past:                                    # 第 1 人有过去、当前不可测
        pre[:, -1, 1, MEA] = 0.0
        for t in range(T - 1 - max(past_measured_frames, 3), T - 1):
            pre[:, t, 1, ACT] = 1.0; pre[:, t, 1, MEA] = 1.0
    q = torch.randn(1, 80, 1 + P_, D, generator=g) * 0.1
    q[:, :, 1:, ACT] = 1.0
    return pre, q

def score(m, pre, q, **flags):
    saved = {k: getattr(m, k, None) for k in flags}
    try:
        for k, v in flags.items(): setattr(m, k, v)
        with torch.inference_mode():
            return m.score_candidates(pre, q).squeeze(0).numpy().copy()
    finally:
        for k, v in saved.items():
            if v is not None: setattr(m, k, v)

R = {}
print(f"TREE = {TREE}\n")
for name in CKPTS:
    if not os.path.exists(CKPTS[name]): print(f"[跳过] {name} 权重缺失"); continue
    m, cfg, T, cls = build(name)
    has = hasattr(type(m), 'mask_past_writes')
    print(f"=== {name}  类 {cls}  prefix 长度 {T}  有 mask_past_writes 属性: {has}")
    r = {'class': cls, 'T': T, 'has_flag': bool(has)}

    # T1 (要求 2)：无过去帧时, 完整模式与只屏蔽过去模式必须完全一致
    pre, q = make(T, 0)
    a = score(m, pre, q)
    b = score(m, pre, q, mask_past_writes=True) if has else a
    r['T1_max_abs_diff'] = float(np.abs(a - b).max())
    r['T1_argmax_same'] = bool(np.argmax(a) == np.argmax(b))
    r['T1_pass'] = bool(r['T1_max_abs_diff'] == 0.0 and r['T1_argmax_same'])
    print(f"  T1 无过去帧: |Δ|最大 {r['T1_max_abs_diff']:.3e}  argmax {np.argmax(a)}/{np.argmax(b)}  "
          f"{'通过' if r['T1_pass'] else '失败'}")

    # T1b：没有【任何】measured(连当前帧也没有) 时也必须一致
    pre0, q0 = make(T, 0); pre0[:, -1, 1:, MEA] = 0.0
    a0 = score(m, pre0, q0); b0 = score(m, pre0, q0, mask_past_writes=True) if has else a0
    r['T1b_max_abs_diff'] = float(np.abs(a0 - b0).max()); r['T1b_pass'] = bool(r['T1b_max_abs_diff'] == 0.0)
    print(f"  T1b 全无 measured: |Δ|最大 {r['T1b_max_abs_diff']:.3e}  {'通过' if r['T1b_pass'] else '失败'}")

    # T2 (开关确实起作用)：有过去帧时必须不同
    pre2, q2 = make(T, 8)
    a2 = score(m, pre2, q2); b2 = score(m, pre2, q2, mask_past_writes=True) if has else a2
    r['T2_max_abs_diff'] = float(np.abs(a2 - b2).max())
    r['T2_pass'] = bool(r['T2_max_abs_diff'] > 0.0) if has else None
    print(f"  T2 有 8 过去帧: |Δ|最大 {r['T2_max_abs_diff']:.3e}  {'通过' if r['T2_pass'] else '失败/NA'}")

    # T3 (对照) use_history=False 的旧开关：无过去帧时【仍会】改变 -> 证明两者语义不同
    c = score(m, pre, q, use_history=False) if hasattr(m, 'use_history') else None
    if c is not None:
        r['T3_old_switch_diff_at_zero_past'] = float(np.abs(a - c).max())
        print(f"  T3 旧开关 use_history=False 在无过去帧时: |Δ|最大 "
              f"{r['T3_old_switch_diff_at_zero_past']:.3e}  (>0 即旧开关连当前帧写入也移除)")

    # T4 (要求 3)：输入张量与模型参数不被改动; gaps/query_gap 不变
    pi, qi = make(T, 8); pc, qc = pi.clone(), qi.clone()
    pstate = {k: v.detach().clone() for k, v in m.state_dict().items()}
    _ = score(m, pi, qi, mask_past_writes=True) if has else None
    r['T4_prefix_unchanged'] = bool(torch.equal(pi, pc)); r['T4_queries_unchanged'] = bool(torch.equal(qi, qc))
    r['T4_params_unchanged'] = all(torch.equal(v, m.state_dict()[k]) for k, v in pstate.items())
    gaps_same = None
    if hasattr(m, 'encode_history'):
        with torch.inference_mode():
            o1 = m.encode_history(pi)
            saved = getattr(m, 'mask_past_writes', None)
            try:
                if has: m.mask_past_writes = True
                o2 = m.encode_history(pi)
            finally:
                if saved is not None: m.mask_past_writes = saved
        def tail(o): return [x for x in (o if isinstance(o, tuple) else (o,))][1:]
        try:
            gaps_same = all(torch.equal(x, y) if torch.is_tensor(x) else x == y
                            for x, y in zip(tail(o1), tail(o2)))
        except Exception: gaps_same = None
    r['T4_derived_unchanged'] = gaps_same
    print(f"  T4 prefix 未改 {r['T4_prefix_unchanged']}  queries 未改 {r['T4_queries_unchanged']}  "
          f"参数未改 {r['T4_params_unchanged']}  gaps/seen 等派生量未改 {gaps_same}")

    # T5 (要求 3)：开关无残留 —— 开过再关必须回到原值; 重复调用幂等
    _ = score(m, pre2, q2, mask_past_writes=True) if has else None
    a2b = score(m, pre2, q2)
    r['T5_no_residual'] = bool(np.abs(a2 - a2b).max() == 0.0)
    r['T5_idempotent'] = bool(np.abs(score(m, pre2, q2, mask_past_writes=True) - b2).max() == 0.0) if has else None
    print(f"  T5 无残留 {r['T5_no_residual']}  幂等 {r['T5_idempotent']}")

    # T6 (如实量化残留通道)：某人有过去但当前不可测 —— gaps/seen 未改, 过去信息仍可经其残留
    ph, qh = make(T, 6, hidden_person_with_past=True)
    ah = score(m, ph, qh); bh = score(m, ph, qh, mask_past_writes=True) if has else ah
    r['T6_hidden_person_diff'] = float(np.abs(ah - bh).max())
    # 回归指纹：关闭新功能时的分数, 用于原版/补丁版逐位对照
    fp = lambda x: hashlib.sha256(np.ascontiguousarray(x, dtype=np.float64).tobytes()).hexdigest()[:32]
    r['FP_off_zero_past'] = fp(a); r['FP_off_no_measured'] = fp(a0)
    r['FP_off_8_past'] = fp(a2); r['FP_off_hidden'] = fp(ah)
    print(f"  回归指纹(关闭态): zero_past {r['FP_off_zero_past'][:16]}  8_past {r['FP_off_8_past'][:16]}")
    print(f"  T6 隐藏人(有过去/当前不可测): |Δ|最大 {r['T6_hidden_person_diff']:.3e}")
    R[name] = r

out = '/home/abc/temp/cc_backstop_20261005/results/unittest_past_write_mask' + \
      ('_patched' if 'patched' in TREE else '_pristine') + '.json'
json.dump(R, open(out, 'w'), indent=1)
print(f"\n写出 {out}")
