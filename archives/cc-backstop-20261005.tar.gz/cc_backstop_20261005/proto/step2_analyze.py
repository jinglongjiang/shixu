# -*- coding: utf-8 -*-
"""第二步结果汇总。严格按用户第三条：报无分歧 episode 数；分歧子集的收益只代表该子集；
按 episode 分组（每 episode 仅一个锚点=首次分歧，故不存在多锚点当独立样本）。"""
import json, glob, collections, numpy as np
rows=[]
for f in sorted(glob.glob('/home/abc/temp/cc_backstop_20261005/results/step2/s*/step2_history_branch.json')):
    rows += json.load(open(f))
print(f"总 episode {len(rows)}   确定性自检全部通过: {all(r['deterministic'] for r in rows)}")
bad=[r for r in rows if not r['deterministic']]
if bad: print(f"  !! 自检失败 {len(bad)} 个: {[(r['seed'],r['case']) for r in bad][:5]}")

nd=[r for r in rows if r['first_div'] is None]
dv=[r for r in rows if r['first_div'] is not None]
print(f"\n[无分歧] {len(nd)}/{len(rows)} = {len(nd)/len(rows)*100:.1f}% 的 episode 始终没有动作分歧")
print(f"[有分歧] {len(dv)}/{len(rows)} = {len(dv)/len(rows)*100:.1f}%")
if dv:
    ds=[r['n_divergent_steps']/r['steps'] for r in dv]
    print(f"  有分歧 episode 内, 分歧步占比 中位 {np.median(ds)*100:.1f}%  首次分歧步 中位 {np.median([r['first_div'] for r in dv]):.0f}")

print("\n[三分类] 仅在有分歧子集上 (阈值 |Δ|<=0.02 且同 terminal 记为后果相近)")
c=collections.Counter(r['klass'] for r in dv)
for k in ('history_beneficial','history_harmful','no_practical_difference'):
    print(f"  {k:26s} {c[k]:4d}  ({c[k]/max(len(dv),1)*100:5.1f}% of 分歧子集, {c[k]/len(rows)*100:5.1f}% of 全部)")

print("\n[按 seed 分组] 分歧子集内 有益/有害/相近, 以及 Δ 的 episode 级均值")
print(f"{'seed':<7}{'无分歧':>7}{'有分歧':>7}{'有益':>6}{'有害':>6}{'相近':>6}{'Δ均值':>10}{'Δ中位':>10}")
for s in sorted({r['seed'] for r in rows}):
    g=[r for r in rows if r['seed']==s]; gd=[r for r in g if r['first_div'] is not None]
    cc=collections.Counter(r['klass'] for r in gd)
    d=[r['delta'] for r in gd]
    print(f"{s:<7}{len(g)-len(gd):>7}{len(gd):>7}{cc['history_beneficial']:>6}{cc['history_harmful']:>6}"
          f"{cc['no_practical_difference']:>6}{np.mean(d):>10.4f}{np.median(d):>10.4f}")

print("\n[终局变化] 分支后 terminal 是否改变 (分歧子集)")
tc=collections.Counter((r['full_terminal'], r['zero_terminal']) for r in dv)
for (f,z),n in sorted(tc.items(), key=lambda x:-x[1]):
    print(f"  有历史={f:<12} 零历史={z:<12} {n:4d}" + ("" if f!=z else "   (相同)"))

print("\n[阈值敏感性] 改变 '后果相近' 的阈值")
for tol in (0.0, 0.01, 0.02, 0.05, 0.10):
    b=h=n=0
    for r in dv:
        same=r['full_terminal']==r['zero_terminal']
        if same and abs(r['delta'])<=tol: n+=1
        elif r['delta']>0: b+=1
        else: h+=1
    print(f"  tol={tol:<5} 有益 {b:4d}  有害 {h:4d}  相近 {n:4d}")

d=np.array([r['delta'] for r in dv])
print(f"\n[Δ 分布] 按 episode 分组 n={len(d)}  均值 {d.mean():+.4f}  中位 {np.median(d):+.4f}  "
      f"标准差 {d.std(ddof=1):.4f}  正号比例 {(d>0).mean()*100:.1f}%")
# episode 级 bootstrap（按 episode 重采样, 非步级）
rng=np.random.RandomState(0)
bs=[rng.choice(d, len(d), replace=True).mean() for _ in range(5000)]
print(f"  episode 级 bootstrap 95% 区间 [{np.percentile(bs,2.5):+.4f}, {np.percentile(bs,97.5):+.4f}]")
print("\n边界: 清空记忆是分布外干预; 以上只说明该干预的影响, 不证明历史有害。")
print("      分歧子集的 Δ 不能换算成整体 SR。")
