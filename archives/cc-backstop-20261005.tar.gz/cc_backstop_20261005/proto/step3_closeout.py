# -*- coding: utf-8 -*-
"""只读收尾 (1)(3): 首次分歧处的实际时间/有效过去帧/padding 占比; 以及 case／seed 分组敏感性。
用 V8 存档动作重放, 零次模型前向, 不跑导航。
"""
import sys, os, json, glob, collections, configparser
import numpy as np, torch
sys.path.insert(0,'/home/abc/workspace/shixu/vendor'); sys.path.insert(1,'/home/abc/workspace/shixu')
import crowd_sim as _cs; assert _cs.__file__.startswith('/home/abc/workspace/shixu/vendor/')
from crowd_sim.envs.utils.action import ActionXY
from shixu.model import build_model, load_weights
from shixu.policy import ValuePolicy
from shixu.observations import OccludedTracks
from shixu.runner import environment
from shixu.features import window
OUT='/home/abc/temp/cc_backstop_20261005/results'
rows=[]
for f in sorted(glob.glob(f'{OUT}/step2/s*/step2_history_branch.json')): rows += json.load(open(f))
arch={}
for s in (419,443,467,491):
    p=f'/home/abc/workspace/shixu/outputs/occlusion_v8/{s}/motion_kda/result.json'
    for e in json.load(open(p))['episodes']:
        arch[(s,e['people'],e['geometry'],e['case'])]=e

pols={}
def getpol(seed):
    if seed in pols: return pols[seed]
    P=f'/home/abc/workspace/shixu/outputs/occlusion_v8/{seed}/motion_kda/model.pt'
    ck=torch.load(P,map_location='cpu',weights_only=False)
    cfg=configparser.ConfigParser(); cfg.read_dict(ck['config'])
    pol=ValuePolicy(build_model(cfg),cfg,'cpu'); load_weights(pol.model,P,'cpu'); pol.model.eval()
    pols[seed]=(pol,cfg); return pols[seed]

envs={}
def getenv(seed,cfg,pol,geom,people):
    k=(seed,geom,people)
    if k not in envs: envs[k]=environment(cfg,pol,geom,people)
    return envs[k]

print(f"{'':2}检查 {len([r for r in rows if r['first_div'] is not None])} 个有分歧 episode", flush=True)
stats=[]
for r in rows:
    k=r['first_div']
    if k is None: continue
    key=(r['seed'],r['people'],r['geometry'],r['case'])
    a=arch.get(key)
    if a is None: continue
    pol,cfg=getpol(r['seed']); env=getenv(r['seed'],cfg,pol,r['geometry'],r['people'])
    pol.reset(); pol.set_phase('test'); env.phase='test'
    env.reset(options={'test_case':int(r['case'])})
    tracks=OccludedTracks(pol.config.getfloat('observation','retention_seconds'))
    for i in range(k):
        st=tracks.observe(env)
        pol.history.append(pol.encode(st))
        env.step(ActionXY(*a['actions'][i]))
    st=tracks.observe(env)
    cur=pol.encode(st)
    pre=window(list(pol.history)+[cur], pol.length, "zero")
    pre=pre[1:]                                     # full_observed_window = False
    act=pre[:,1:,12]>0; mea=(pre[:,1:,10]>0)&act
    past_mea=mea[:-1]                               # 排除当前帧
    nz=int((pre.reshape(len(pre),-1)!=0).any(axis=1).sum())   # 非全零(非 padding)的帧数
    stats.append(dict(seed=r['seed'],people=r['people'],geometry=r['geometry'],case=r['case'],
        klass=r.get('klass'), delta=r.get('delta'), first_div=k,
        time_s=float(env.global_time),
        past_frames=len(pol.history),
        prefix_len=int(len(pre)),
        nonpad_frames=nz,
        pad_fraction=float(1-nz/len(pre)),
        past_measured_total=int(past_mea.sum()),
        past_measured_per_person=float(past_mea.sum()/max(past_mea.shape[1],1)),
        cur_measured=int(mea[-1].sum())))
json.dump(stats, open(f'{OUT}/step3_closeout.json','w'), indent=1)

S=stats
print(f"\n[1] 首次分歧处的实际时间与历史量 (n={len(S)})")
for nm,key in (('实际时间 s','time_s'),('过去帧数 len(history)','past_frames'),
               ('非 padding 帧数 /23','nonpad_frames'),('padding 占比','pad_fraction'),
               ('过去 measured 帧总数(所有人)','past_measured_total'),
               ('过去 measured 帧数/人','past_measured_per_person')):
    v=np.array([s[key] for s in S],float)
    print(f"  {nm:<30} 中位 {np.median(v):8.3f}   均值 {v.mean():8.3f}   "
          f"p10 {np.percentile(v,10):7.3f}  p90 {np.percentile(v,90):7.3f}")
print(f"\n  过去 measured 帧数/人 == 0 的 episode: "
      f"{sum(1 for s in S if s['past_measured_per_person']==0)}/{len(S)} = "
      f"{sum(1 for s in S if s['past_measured_per_person']==0)/len(S)*100:.1f}%")
print(f"  首次分歧在前 2 步 (k<=1) 的 episode: {sum(1 for s in S if s['first_div']<=1)}/{len(S)} = "
      f"{sum(1 for s in S if s['first_div']<=1)/len(S)*100:.1f}%")

print("\n[1b] 按『过去 measured 帧数/人』分桶 × 三分类")
def bucket(x):
    return '0' if x==0 else ('(0,1]' if x<=1 else ('(1,3]' if x<=3 else ('(3,10]' if x<=10 else '>10')))
g=collections.defaultdict(collections.Counter); gd=collections.defaultdict(list)
for s in S:
    b=bucket(s['past_measured_per_person']); g[b][s['klass']]+=1; gd[b].append(s['delta'])
print(f"{'桶':<8}{'n':>5}{'有益':>6}{'有害':>6}{'相近':>6}{'Δ均值':>10}")
for b in ('0','(0,1]','(1,3]','(3,10]','>10'):
    if b not in g: continue
    c=g[b]; n=sum(c.values())
    print(f"{b:<8}{n:>5}{c['history_beneficial']:>6}{c['history_harmful']:>6}"
          f"{c['no_practical_difference']:>6}{np.mean(gd[b]):>10.4f}")

print("\n[3] 分组敏感性: case 在 4 个 seed 间复用, 故同 case 跨 seed 不独立")
d=np.array([s['delta'] for s in S],float)
rng=np.random.RandomState(0)
def clustered(groups, n=5000):
    keys=sorted(set(groups), key=repr)
    idx=[np.array([i for i,gg in enumerate(groups) if gg==k]) for k in keys]
    K=len(keys); out=[]
    for _ in range(n):
        pick=rng.randint(0, K, K)                      # 整数索引, 支持元组型簇键
        out.append(np.concatenate([d[idx[j]] for j in pick]).mean())
    return np.percentile(out,2.5), np.percentile(out,97.5), K
e_lo,e_hi=np.percentile([rng.choice(d,len(d),replace=True).mean() for _ in range(5000)],[2.5,97.5])
c_lo,c_hi,nc=clustered([s['case'] for s in S])
s_lo,s_hi,ns=clustered([s['seed'] for s in S])
cs_lo,cs_hi,ncs=clustered([(s['case'],s['people'],s['geometry']) for s in S])
print(f"  Δ 均值 {d.mean():+.4f}")
print(f"  episode 级 bootstrap            95% [{e_lo:+.4f}, {e_hi:+.4f}]   (假设 256 独立, 偏窄)")
print(f"  按 case 聚类 ({nc} 簇)            95% [{c_lo:+.4f}, {c_hi:+.4f}]")
print(f"  按 case×格 聚类 ({ncs} 簇)        95% [{cs_lo:+.4f}, {cs_hi:+.4f}]")
print(f"  按 seed 聚类 ({ns} 簇)            95% [{s_lo:+.4f}, {s_hi:+.4f}]   (簇数过少, 仅供参考)")
print("\n  等效界 ±0.02: 以上任一区间都未落在界内 -> 只能说『未发现稳定平均增益』, 不能说已证明实用等效。")
