# 收尾：屏蔽过去观测记忆写入的诊断开关

日期 2026-10-05。**状态：工具任务完成。补丁独立归档，未合入主仓库，是否采用另行明确。**

## 这个开关到底测什么（限定表述）

`mask_past_writes = True` ⇒ **屏蔽过去观测的记忆写入**，保留当前帧的编码与写入。

**它不是「移除全部过去信息」。** `gaps` / `query_gap` / `seen` 等历史派生量一律保留不动
（这是按要求，避免意外改动时间间隔）。因此它测的是：
**在这些标量信息不变的前提下，过去观测【写入记忆】的额外作用。**

## 与旧开关的区别（这是本次修正的核心）

| | 旧 `use_history=False` | 新 `mask_past_writes=True` |
|---|---|---|
| 当前帧的记忆写入 | **也被移除** | 保留 |
| 过去观测的记忆写入 | 移除 | 移除 |
| 无过去帧时与完整模式 | **不同**（motion_kda 0.200 / motion_gru 0.058） | **逐位相同（0.000e+00）** |

旧开关的这一混杂是此前归因范围受限的根源。

## 单测结果（三个类 / 三个臂，无导航）

| 测试 | motion_kda | gru_context | motion_gru |
|---|---|---|---|
| T1 无过去帧：完整 vs 新模式 | 0.000e+00，argmax 48/48 | 0.000e+00，48/48 | 0.000e+00，51/51 |
| T1b 连当前帧也无 measured | 0.000e+00 | 0.000e+00 | 0.000e+00 |
| T2 有 8 过去帧（开关起作用） | 0.142 | 0.184 | 0.061 |
| T4 prefix/queries/参数/派生量未改动 | 全 True | 全 True | 全 True |
| T5 无残留 + 幂等 | True / True | True / True | True / True |
| 回归：关闭态与原版逐位一致 | 4/4 指纹一致 | 4/4 | 4/4 |

覆盖类：`MotionValueModel`（motion_kda / motion_gru）、`OcclusionValueModel`（gru_context）、
`MemoryValueModel`（已打补丁，本轮无对应 V8 权重故未实测）。

## T6 的 0.449 必须这样读（限定表述）

隐藏人（有过去观测、当前不可测）时 \|Δscore\| 最大值：
motion_kda 0.047 / gru_context **0.449** / motion_gru 0.059。

**只能说明：在该合成测试的输入下，该模型输出对「过去观测写入」这一通道敏感。**

不能据此说：
- GRU 比 KDA 更依赖历史（不同类、不同输入构造、单一合成样本，不构成跨模型比较）；
- 这是导航收益（它是打分差，不是任何闭环结果）。

## 边界

- 单测通过只说明**工具行为正确**，不说明历史有价值。
- 本轮未跑任何导航，未重跑此前的 256 个 episode。
- 补丁**不合入** `/home/abc/workspace/shixu`；改动仅存在于隔离副本与 `.patch` 文件。
- 后续是否采用该补丁另行明确，**不自动转成 80009 实验**；我不再索要 CV419 权重。

## 交付清单

| 文件 | 内容 |
|---|---|
| `past_write_mask.patch` | 33 行变更，覆盖三个类；已验证可干净应用到原版树（`patch -p1 --dry-run` 通过） |
| `test_past_write_mask.py` | 单测，含回归指纹；`TREE` 环境变量切换原版/补丁树 |
| `results/unittest_past_write_mask_pristine.json` | 原版树结果 |
| `results/unittest_past_write_mask_patched.json` | 补丁树结果 |
| `shixu_patched/` | 隔离副本（不含 outputs/权重） |
